# -*- coding: utf-8 -*-
"""
Created on Sat Apr 28 11:19:47 2018

@author: DELL
"""

import os
os.environ["PATH"] += os.pathsep + 'C:/Program Files (x86)/Graphviz2.38/bin/'

